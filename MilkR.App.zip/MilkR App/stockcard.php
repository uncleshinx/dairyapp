<?php require_once('Connections/register.php'); ?>
<?php
if (!function_exists("GetSQLValueString")) {
function GetSQLValueString($theValue, $theType, $theDefinedValue = "", $theNotDefinedValue = "") 
{
  if (PHP_VERSION < 6) {
    $theValue = get_magic_quotes_gpc() ? stripslashes($theValue) : $theValue;
  }

  $theValue = function_exists("mysql_real_escape_string") ? mysql_real_escape_string($theValue) : mysql_escape_string($theValue);

  switch ($theType) {
    case "text":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;    
    case "long":
    case "int":
      $theValue = ($theValue != "") ? intval($theValue) : "NULL";
      break;
    case "double":
      $theValue = ($theValue != "") ? doubleval($theValue) : "NULL";
      break;
    case "date":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;
    case "defined":
      $theValue = ($theValue != "") ? $theDefinedValue : $theNotDefinedValue;
      break;
  }
  return $theValue;
}
}

$currentPage = $_SERVER["PHP_SELF"];

if ((isset($_GET['cowID'])) && ($_GET['cowID'] != "")) {
  $deleteSQL = sprintf("DELETE FROM cowrecord WHERE cowID=%s",
                       GetSQLValueString($_GET['cowID'], "int"));

  mysql_select_db($database_register, $register);
  $Result1 = mysql_query($deleteSQL, $register) or die(mysql_error());
}

$maxRows_Recordset1 = 1;
$pageNum_Recordset1 = 0;
if (isset($_GET['pageNum_Recordset1'])) {
  $pageNum_Recordset1 = $_GET['pageNum_Recordset1'];
}
$startRow_Recordset1 = $pageNum_Recordset1 * $maxRows_Recordset1;

mysql_select_db($database_register, $register);
$query_Recordset1 = "SELECT * FROM cowrecord";
$query_limit_Recordset1 = sprintf("%s LIMIT %d, %d", $query_Recordset1, $startRow_Recordset1, $maxRows_Recordset1);
$Recordset1 = mysql_query($query_limit_Recordset1, $register) or die(mysql_error());
$row_Recordset1 = mysql_fetch_assoc($Recordset1);

if (isset($_GET['totalRows_Recordset1'])) {
  $totalRows_Recordset1 = $_GET['totalRows_Recordset1'];
} else {
  $all_Recordset1 = mysql_query($query_Recordset1);
  $totalRows_Recordset1 = mysql_num_rows($all_Recordset1);
}
$totalPages_Recordset1 = ceil($totalRows_Recordset1/$maxRows_Recordset1)-1;

mysql_select_db($database_register, $register);
$query_update = "SELECT * FROM cowrecord";
$update = mysql_query($query_update, $register) or die(mysql_error());
$row_update = mysql_fetch_assoc($update);
$totalRows_update = mysql_num_rows($update);

$queryString_Recordset1 = "";
if (!empty($_SERVER['QUERY_STRING'])) {
  $params = explode("&", $_SERVER['QUERY_STRING']);
  $newParams = array();
  foreach ($params as $param) {
    if (stristr($param, "pageNum_Recordset1") == false && 
        stristr($param, "totalRows_Recordset1") == false) {
      array_push($newParams, $param);
    }
  }
  if (count($newParams) != 0) {
    $queryString_Recordset1 = "&" . htmlentities(implode("&", $newParams));
  }
}
$queryString_Recordset1 = sprintf("&totalRows_Recordset1=%d%s", $totalRows_Recordset1, $queryString_Recordset1);
?>
<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Log In</title>
<link href="jquery-mobile/jquery.mobile-1.3.0.min.css" rel="stylesheet" type="text/css">
<link href="jQueryAssets/jquery.ui.core.min.css" rel="stylesheet" type="text/css">
<link href="jQueryAssets/jquery.ui.theme.min.css" rel="stylesheet" type="text/css">
<script src="jquery-mobile/jquery-1.11.1.min.js" type="text/javascript"></script>
<script src="jquery-mobile/jquery.mobile-1.3.0.min.js" type="text/javascript"></script><script type="text/javascript" charset="utf-8" src="PushPluginProxy.js"></script>
<script type="text/javascript" charset="utf-8" src="cordova.js"></script>
</head>

<body>
<div data-role="page" id="page">
<center>
  <div data-role="header">
    <h1><img src="assets/logo.png" height="165">&nbsp;</h1>
  </div>
 
 
  
  <div class="ui-bar-a" data-role="content">
  <form id="stockcard">
  <a href="cowrecord.php" data-role="button" data-icon="arrow-l" data-iconpos="top">Close</a>
  <div data-role="fieldcontain">
    <center>
    </center>
    <p>&nbsp;</p>
    <table width="400" border="1" align="center">
      <tbody>
        <tr>
          <td width="203" class="ui-bar-b">Cow ID</td>
          <td width="181" class="ui-bar-e"><?php echo $row_Recordset1['cowname']; ?></td>
        </tr>
        <tr>
          <td class="ui-bar-b">D.O.B</td>
          <td class="ui-bar-e"><?php echo $row_Recordset1['dob']; ?></td>
        </tr>
        <tr>
          <td class="ui-bar-b">Sire</td>
          <td class="ui-bar-e"><?php echo $row_Recordset1['sire']; ?></td>
        </tr>
        <tr>
          <td class="ui-bar-b">Dam</td>
          <td class="ui-bar-e"><?php echo $row_Recordset1['dam']; ?></td>
        </tr>
        <tr>
          <td class="ui-bar-b">Weight @ 1st service</td>
          <td class="ui-bar-e"><?php echo $row_Recordset1['firstserviceweight']; ?></td>
        </tr>
        <tr>
          <td class="ui-bar-b">Age @ 1st service</td>
          <td class="ui-bar-e"><?php echo $row_Recordset1['firstserviceage']; ?></td>
        </tr>
        <tr>
          <td class="ui-bar-b">Age @ 1st calving</td>
          <td class="ui-bar-e"><?php echo $row_Recordset1['firstcalvingage']; ?></td>
        </tr>
        <tr>
          <td class="ui-bar-b">Age @ conception</td>
          <td class="ui-bar-e"><?php echo $row_Recordset1['conceptionage']; ?></td>
        </tr>
        <tr>
          <td class="ui-bar-b">Date of Heat</td>
          <td class="ui-bar-e"><?php echo $row_Recordset1['heatdate']; ?></td>
        </tr>
        <tr>
          <td class="ui-bar-b">Date of A.I</td>
          <td class="ui-bar-e"><?php echo $row_Recordset1['aidate']; ?></td>
        </tr>
        <tr>
          <td class="ui-bar-b">Date of Service</td>
          <td class="ui-bar-e"><?php echo $row_Recordset1['dateofservice']; ?></td>
        </tr>
        <tr>
          <td class="ui-bar-b">Pregnacy Diagnosis date</td>
          <td class="ui-bar-e"><?php echo $row_Recordset1['pregnancydiaonosis']; ?></td>
        </tr>
        <tr>
          <td class="ui-bar-b">Date of calving</td>
          <td class="ui-bar-e"><?php echo $row_Recordset1['datecalved']; ?></td>
        </tr>
        <tr>
          <td class="ui-bar-b">Date due to calf</td>
          <td class="ui-bar-e"><?php echo $row_Recordset1['duetocalf']; ?></td>
        </tr>
        <tr>
          <td class="ui-bar-b">Date to dry</td>
          <td class="ui-bar-e"><?php echo $row_Recordset1['datetodry']; ?></td>
        </tr>
        <tr>
          <td class="ui-bar-b">Sex of calf</td>
          <td class="ui-bar-e"><?php echo $row_Recordset1['calfsex']; ?></td>
        </tr>
        <tr>
          <td class="ui-bar-b">Calving Interval</td>
          <td class="ui-bar-e"><?php echo $row_Recordset1['calvinginterval']; ?></td>
        </tr>
      </tbody>
    </table>
    <p>&nbsp;</p>
    <p class="ui-bar-e">Total Records: <?php echo $totalRows_Recordset1 ?> <a href="<?php printf("%s?pageNum_Recordset1=%d%s", $currentPage, max(0, $pageNum_Recordset1 - 1), $queryString_Recordset1); ?>"> Previous </a> <a href="<?php printf("%s?pageNum_Recordset1=%d%s", $currentPage, min($totalPages_Recordset1, $pageNum_Recordset1 + 1), $queryString_Recordset1); ?>">Next</a> </p>
    <div data-role="fieldcontain"></div>
    <div data-role="fieldcontain">
      <label for="number"></label>
    </div>
  </form>
  </div>
  
  
  
</div>
  <div data-role="footer">
    <h4><img src="assets/Kalloni.png" width="205"></h4>
  </div>
  </center>
</div>
</body>
</html>
<?php
mysql_free_result($Recordset1);

mysql_free_result($update);
?>
