<?php require_once('Connections/register.php'); ?>
<?php
if (!function_exists("GetSQLValueString")) {
function GetSQLValueString($theValue, $theType, $theDefinedValue = "", $theNotDefinedValue = "") 
{
  if (PHP_VERSION < 6) {
    $theValue = get_magic_quotes_gpc() ? stripslashes($theValue) : $theValue;
  }

  $theValue = function_exists("mysql_real_escape_string") ? mysql_real_escape_string($theValue) : mysql_escape_string($theValue);

  switch ($theType) {
    case "text":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;    
    case "long":
    case "int":
      $theValue = ($theValue != "") ? intval($theValue) : "NULL";
      break;
    case "double":
      $theValue = ($theValue != "") ? doubleval($theValue) : "NULL";
      break;
    case "date":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;
    case "defined":
      $theValue = ($theValue != "") ? $theDefinedValue : $theNotDefinedValue;
      break;
  }
  return $theValue;
}
}

$editFormAction = $_SERVER['PHP_SELF'];
if (isset($_SERVER['QUERY_STRING'])) {
  $editFormAction .= "?" . htmlentities($_SERVER['QUERY_STRING']);
}

if ((isset($_POST["MM_insert"])) && ($_POST["MM_insert"] == "inputs")) {
  $insertSQL = sprintf("INSERT INTO inputpurchase (`date`, `input`, quantity, cost, lifespan, depreciation) VALUES (%s, %s, %s, %s, %s, %s)",
                       GetSQLValueString($_POST['date'], "date"),
                       GetSQLValueString($_POST['input'], "text"),
                       GetSQLValueString($_POST['quantity'], "int"),
                       GetSQLValueString($_POST['pv'], "double"),
                       GetSQLValueString($_POST['lifespan'], "double"),
                       GetSQLValueString($_POST['depreciation'], "double"));

  mysql_select_db($database_register, $register);
  $Result1 = mysql_query($insertSQL, $register) or die(mysql_error());

  $insertGoTo = "financial.php";
  if (isset($_SERVER['QUERY_STRING'])) {
    $insertGoTo .= (strpos($insertGoTo, '?')) ? "&" : "?";
    $insertGoTo .= $_SERVER['QUERY_STRING'];
  }
  header(sprintf("Location: %s", $insertGoTo));
}

mysql_select_db($database_register, $register);
$query_financial = "SELECT * FROM inputpurchase";
$financial = mysql_query($query_financial, $register) or die(mysql_error());
$row_financial = mysql_fetch_assoc($financial);
$totalRows_financial = mysql_num_rows($financial);

mysql_select_db($database_register, $register);
$query_expense = "SELECT * FROM about";
$expense = mysql_query($query_expense, $register) or die(mysql_error());
$row_expense = mysql_fetch_assoc($expense);
$totalRows_expense = mysql_num_rows($expense);
?>
<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Log In</title>
<link href="jquery-mobile/jquery.mobile-1.3.0.min.css" rel="stylesheet" type="text/css">
<link href="jQueryAssets/jquery.ui.core.min.css" rel="stylesheet" type="text/css">
<link href="jQueryAssets/jquery.ui.theme.min.css" rel="stylesheet" type="text/css">
<link href="jQueryAssets/jquery.ui.datepicker.min.css" rel="stylesheet" type="text/css">
<script src="jquery-mobile/jquery-1.11.1.min.js" type="text/javascript"></script>
<script src="jquery-mobile/jquery.mobile-1.3.0.min.js" type="text/javascript"></script>
<script type="text/javascript" charset="utf-8" src="PushPluginProxy.js"></script>
<script type="text/javascript" charset="utf-8" src="cordova.js"></script>
<script src="jQueryAssets/jquery.ui-1.10.4.datepicker.min.js" type="text/javascript"></script>
<script language='JavaScript' type='text/javascript' src='JScript/CalculatedField.js'></script>
</head>

<body>
<div data-role="page" id="page">
<center>
  <div data-role="header">
    <h1><img src="assets/logo.png" height="165">&nbsp;</h1>
  </div>
  <form method="POST" action="<?php echo $editFormAction; ?>" id="inputs" name="inputs">
    <div class="ui-bar-a" data-role="content">
    <a href="financialrecords.php" data-role="button" data-icon="arrow-l" data-iconpos="top">Return to Menu</a>
    <p>Date<input name="date" type="date" id="date">
    <div data-role="fieldcontain">
      <label for="input">Name of Input</label>
      <input type="text" name="input" id="input" value="" placeholder="name of input" />
    </div>
    <div data-role="fieldcontain">
    <label for="quantity">How many?</label>
    <input type="number" name="quantity" id="quantity" value="" placeholder="Quantity" />
    <div data-role="fieldcontain">
    <p>
      <label for="pv">Purchase Value  </label>
      $<input type="number" name="pv" id="pv" value="" placeholder="Cost of Input" />
    </p>
    <table width="432" border="1">
      <tbody>
        <tr> </tr>
      </tbody>
    </table>
    <table width="400" border="1">
      <tbody>
        <tr>
          <td width="276" class="ui-bar-b">Lifespan</td>
          <td width="108" class="ui-bar-e">Daily Cost</td>
        </tr>
        <tr>
          <td class="ui-bar-b">&nbsp;
            <div data-role="fieldcontain">
              <input type="number" name="lifespan" id="lifespan" value="" Placeholder="in Years" />
              <input type="hidden" name="lifee" id="lifee">
            </div></td>
          <td class="ui-bar-e">&nbsp;
            <div data-role="fieldcontain">
              <label for="depreciation">$</label>
              <input name="depreciation" type="number" class="ui-bar-e" id="depreciation" value=""  />
              <input type="hidden" name="dep" id="dep">
            </div></td>
        </tr>
      </tbody>
    </table><div data-role="fieldcontain"> <strong>
      <button>Save New Input</button>
    </strong>
    </div>
    <input type="hidden" name="MM_insert" value="inputs">
  </form>
  <script>
function calcField_inputs(){

  CalcField.addEquation('inputs', 'depreciation=pv/lifespan');
}
calcField_inputs();
  </script>
  <p>&nbsp;</p>
</div>
      
     
<div data-role="footer">
    <h4><img src="assets/Kalloni.png" width="205"></h4>
  </div>
  
  
  
<script type="text/javascript">
$(function() {
	$( "#Datepicker1" ).datepicker(); 
});
</script>
</body>
</html>
<?php
mysql_free_result($financial);

mysql_free_result($expense);
?>
