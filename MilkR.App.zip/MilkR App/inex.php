<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Log In</title>
<link href="jquery-mobile/jquery.mobile-1.3.0.min.css" rel="stylesheet" type="text/css">
<link href="jQueryAssets/jquery.ui.core.min.css" rel="stylesheet" type="text/css">
<link href="jQueryAssets/jquery.ui.theme.min.css" rel="stylesheet" type="text/css">
<link href="jQueryAssets/jquery.ui.datepicker.min.css" rel="stylesheet" type="text/css">
<script src="jquery-mobile/jquery-1.11.1.min.js" type="text/javascript"></script>
<script src="jquery-mobile/jquery.mobile-1.3.0.min.js" type="text/javascript"></script>
<script type="text/javascript" charset="utf-8" src="PushPluginProxy.js"></script>
<script type="text/javascript" charset="utf-8" src="cordova.js"></script>
<script src="jQueryAssets/jquery.ui-1.10.4.datepicker.min.js" type="text/javascript"></script>
<script language='JavaScript' type='text/javascript' src='JScript/CalculatedField.js'></script>
</head>

<body>
<div data-role="page" id="page">
<center>
  <div data-role="header">
    <h1><img src="assets/logo.png" height="165">&nbsp;</h1>
  </div>
  <form id="inex" name="inex" method="post">
    <div class="ui-bar-a" data-role="content">
    
    <input type="text" id="Datepicker1" placeholder="Select Date">
    <div data-role="fieldcontain">
      <label for="cashin">$</label>
      <input name="cashin" type="number" id="cashin" placeholder="Cash Received" value="" readonly="readonly" />
    </div>
    <div data-role="fieldcontain">
      <label for="cashout">$</label>
      <input name="cashout" type="number" id="cashout" placeholder="Expenditure" value="" readonly="readonly" />
    </div>
    <div data-role="fieldcontain">
      <label for="balance">Balance is   $</label>
      
      <input name="balance" type="number" id="balance" placeholder="Balance" value="" readonly="readonly" />
      <input type="hidden" name="balance1" id="balance1">
    </div>
    
    </div>
  </form>
  <script>
function calcField_inex(){
  CalcField.addEquation('inex', 'balance=cashin-cashout');
}
calcField_inex();
  </script>
</div>
  </div>
  <div data-role="footer">
    <h4><img src="assets/Kalloni.png" width="205"></h4>
  </div>
  </center>
</div>
<script type="text/javascript">
$(function() {
	$( "#Datepicker1" ).datepicker(); 
});
</script>
</body>
</html>