<?php require_once('Connections/register.php'); ?>
<?php require_once('Connections/register.php'); ?>
<?php
if (!function_exists("GetSQLValueString")) {
function GetSQLValueString($theValue, $theType, $theDefinedValue = "", $theNotDefinedValue = "") 
{
  if (PHP_VERSION < 6) {
    $theValue = get_magic_quotes_gpc() ? stripslashes($theValue) : $theValue;
  }

  $theValue = function_exists("mysql_real_escape_string") ? mysql_real_escape_string($theValue) : mysql_escape_string($theValue);

  switch ($theType) {
    case "text":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;    
    case "long":
    case "int":
      $theValue = ($theValue != "") ? intval($theValue) : "NULL";
      break;
    case "double":
      $theValue = ($theValue != "") ? doubleval($theValue) : "NULL";
      break;
    case "date":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;
    case "defined":
      $theValue = ($theValue != "") ? $theDefinedValue : $theNotDefinedValue;
      break;
  }
  return $theValue;
}
}

$editFormAction = $_SERVER['PHP_SELF'];
if (isset($_SERVER['QUERY_STRING'])) {
  $editFormAction .= "?" . htmlentities($_SERVER['QUERY_STRING']);
}

if ((isset($_POST["MM_insert"])) && ($_POST["MM_insert"] == "cowrecord")) {
  $insertSQL = sprintf("INSERT INTO cowrecord (cowname, dob, sire, dam, firstserviceweight, firstserviceage, firstcalvingage, conceptionage) VALUES (%s, %s, %s, %s, %s, %s, %s, %s)",
                       GetSQLValueString($_POST['cowname'], "text"),
                       GetSQLValueString($_POST['dob'], "date"),
                       GetSQLValueString($_POST['sire'], "text"),
                       GetSQLValueString($_POST['dam'], "text"),
                       GetSQLValueString($_POST['firstserviceweight'], "double"),
                       GetSQLValueString($_POST['number'], "double"),
                       GetSQLValueString($_POST['number'], "double"),
                       GetSQLValueString($_POST['number'], "double"));

  mysql_select_db($database_register, $register);
  $Result1 = mysql_query($insertSQL, $register) or die(mysql_error());

  $insertGoTo = "stockcard.php";
  if (isset($_SERVER['QUERY_STRING'])) {
    $insertGoTo .= (strpos($insertGoTo, '?')) ? "&" : "?";
    $insertGoTo .= $_SERVER['QUERY_STRING'];
  }
  header(sprintf("Location: %s", $insertGoTo));
}

mysql_select_db($database_register, $register);
$query_cowrecord = "SELECT * FROM cowrecord";
$cowrecord = mysql_query($query_cowrecord, $register) or die(mysql_error());
$row_cowrecord = mysql_fetch_assoc($cowrecord);
$totalRows_cowrecord = mysql_num_rows($cowrecord);
?>
<!doctype html>
<html><head>
<meta charset="utf-8">

<title>New Cow Record</title>
<link href="jquery-mobile/jquery.mobile-1.3.0.min.css" rel="stylesheet" type="text/css">
<link href="jQueryAssets/jquery.ui.core.min.css" rel="stylesheet" type="text/css">
<link href="jQueryAssets/jquery.ui.theme.min.css" rel="stylesheet" type="text/css">
<script src="jquery-mobile/jquery-1.11.1.min.js" type="text/javascript"></script>
<script src="jquery-mobile/jquery.mobile-1.3.0.min.js" type="text/javascript"></script><script type="text/javascript" charset="utf-8" src="PushPluginProxy.js"></script>
<script type="text/javascript" charset="utf-8" src="cordova.js"></script>
</head>

<body>
<div data-role="page" id="page">
<center>
  <div data-role="header">
    <h1><img src="assets/logo.png" height="165">&nbsp;</h1>
  </div>
 
 
  
  <div class="ui-bar-a" data-role="content">
 <form action="<?php echo $editFormAction; ?>" name="cowrecord" method="POST" id="cowrecord">
 
 <a href="cowrecord.php" data-role="button" data-icon="arrow-l" data-iconpos="top">Close</a>
  <div data-role="fieldcontain">
    <label for="cowname"></label>
    <input type="text" name="cowname" id="cowname" value="" placeholder="Name of Cow" />
  </div>
  <div data-role="fieldcontain">
    <input name="dob" type="date" id="dob" form="cowrecord" autocomplete="on" value="" placeholder="Date of Birth" />
  </div>
<div data-role="fieldcontain">
  <label for="sire"></label>
    <input type="text" name="sire" id="sire" value="" placeholder="Name of Sire (baba)" />
</div>
   <div data-role="fieldcontain">
    <label for="sire"></label>
    <input type="text" name="dam" id="dam" value="" placeholder="Name of Dam (mai)" />
  </div>
   <div data-role="fieldcontain">
     <label for="firstserviceweight"></label>
     Weight at first service<input type="number" name="firstserviceweight" id="firstserviceweight" value="" placeholder="in kgs" />
   </div>
 
   
     <div data-role="fieldcontain">
       <label for="number">Age at 1st service</label>
       <input type="number" name="number" id="number" value=""  placeholder="in Years"/>
     </div>
     <div data-role="fieldcontain">
       <label for="number">Age at 1st calving</label>
       <input type="number" name="number" id="number" value=""  placeholder="in Years"/>
     </div>
     <div data-role="fieldcontain">
       <label for="number">Age at conception</label>
       <input type="number" name="number" id="number" value=""  placeholder="in Years"/>
     </div>
  <div data-role="fieldcontain"> <strong>
      <button>Save Cow Record</button>
    </strong>
    </div>
<input type="hidden" name="MM_insert" value="cowrecord">
<input type="hidden" name="MM_insert" value="cowrecord">
</div>
 
 
 </form>
  
  
  <div data-role="footer">
    <h4><img src="assets/Kalloni.png" width="205"></h4>
  </div>
  </center>
</div>
</body>
</html>
<?php
mysql_free_result($cowrecord);

mysql_free_result($cowrecord);
?>
