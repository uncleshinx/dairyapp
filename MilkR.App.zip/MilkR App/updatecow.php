<?php require_once('Connections/register.php'); ?>
<?php require_once('Connections/register.php'); ?>
<?php
if (!function_exists("GetSQLValueString")) {
function GetSQLValueString($theValue, $theType, $theDefinedValue = "", $theNotDefinedValue = "") 
{
  if (PHP_VERSION < 6) {
    $theValue = get_magic_quotes_gpc() ? stripslashes($theValue) : $theValue;
  }

  $theValue = function_exists("mysql_real_escape_string") ? mysql_real_escape_string($theValue) : mysql_escape_string($theValue);

  switch ($theType) {
    case "text":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;    
    case "long":
    case "int":
      $theValue = ($theValue != "") ? intval($theValue) : "NULL";
      break;
    case "double":
      $theValue = ($theValue != "") ? doubleval($theValue) : "NULL";
      break;
    case "date":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;
    case "defined":
      $theValue = ($theValue != "") ? $theDefinedValue : $theNotDefinedValue;
      break;
  }
  return $theValue;
}
}

if (!function_exists("GetSQLValueString")) {
function GetSQLValueString($theValue, $theType, $theDefinedValue = "", $theNotDefinedValue = "") 
{
  if (PHP_VERSION < 6) {
    $theValue = get_magic_quotes_gpc() ? stripslashes($theValue) : $theValue;
  }

  $theValue = function_exists("mysql_real_escape_string") ? mysql_real_escape_string($theValue) : mysql_escape_string($theValue);

  switch ($theType) {
    case "text":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;    
    case "long":
    case "int":
      $theValue = ($theValue != "") ? intval($theValue) : "NULL";
      break;
    case "double":
      $theValue = ($theValue != "") ? doubleval($theValue) : "NULL";
      break;
    case "date":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;
    case "defined":
      $theValue = ($theValue != "") ? $theDefinedValue : $theNotDefinedValue;
      break;
  }
  return $theValue;
}
}

$currentPage = $_SERVER["PHP_SELF"];

$maxRows_cowrecord = 1;
$pageNum_cowrecord = 0;
if (isset($_GET['pageNum_cowrecord'])) {
  $pageNum_cowrecord = $_GET['pageNum_cowrecord'];
}
$startRow_cowrecord = $pageNum_cowrecord * $maxRows_cowrecord;

$colname_cowrecord = "-1";
if (isset($_GET['cowname'])) {
  $colname_cowrecord = $_GET['cowname'];
}
mysql_select_db($database_register, $register);
$query_cowrecord = sprintf("SELECT * FROM cowrecord WHERE cowname = %s", GetSQLValueString($colname_cowrecord, "text"));
$query_limit_cowrecord = sprintf("%s LIMIT %d, %d", $query_cowrecord, $startRow_cowrecord, $maxRows_cowrecord);
$cowrecord = mysql_query($query_limit_cowrecord, $register) or die(mysql_error());
$row_cowrecord = mysql_fetch_assoc($cowrecord);

if (isset($_GET['totalRows_cowrecord'])) {
  $totalRows_cowrecord = $_GET['totalRows_cowrecord'];
} else {
  $all_cowrecord = mysql_query($query_cowrecord);
  $totalRows_cowrecord = mysql_num_rows($all_cowrecord);
}
$totalPages_cowrecord = ceil($totalRows_cowrecord/$maxRows_cowrecord)-1;

mysql_select_db($database_register, $register);
$query_Recordset1 = "SELECT * FROM login";
$Recordset1 = mysql_query($query_Recordset1, $register) or die(mysql_error());
$row_Recordset1 = mysql_fetch_assoc($Recordset1);
$totalRows_Recordset1 = mysql_num_rows($Recordset1);

$queryString_cowrecord = "";
if (!empty($_SERVER['QUERY_STRING'])) {
  $params = explode("&", $_SERVER['QUERY_STRING']);
  $newParams = array();
  foreach ($params as $param) {
    if (stristr($param, "pageNum_cowrecord") == false && 
        stristr($param, "totalRows_cowrecord") == false) {
      array_push($newParams, $param);
    }
  }
  if (count($newParams) != 0) {
    $queryString_cowrecord = "&" . htmlentities(implode("&", $newParams));
  }
}
$queryString_cowrecord = sprintf("&totalRows_cowrecord=%d%s", $totalRows_cowrecord, $queryString_cowrecord);
?>
<!doctype html>
<html><head>
<meta charset="utf-8">

<title>New Cow Record</title>
<link href="jquery-mobile/jquery.mobile-1.3.0.min.css" rel="stylesheet" type="text/css">
<link href="jQueryAssets/jquery.ui.core.min.css" rel="stylesheet" type="text/css">
<link href="jQueryAssets/jquery.ui.theme.min.css" rel="stylesheet" type="text/css">
<script src="jquery-mobile/jquery-1.11.1.min.js" type="text/javascript"></script>
<script src="jquery-mobile/jquery.mobile-1.3.0.min.js" type="text/javascript"></script><script type="text/javascript" charset="utf-8" src="PushPluginProxy.js"></script>
<script type="text/javascript" charset="utf-8" src="cordova.js"></script>
</head>

<body>
<div data-role="page" id="page">
<center>
  <div data-role="header">
    <h1><img src="assets/logo.png" height="165">&nbsp;</h1>
  </div>
Welcome, <?php echo $row_Recordset1['firstname']; ?> <?php echo $row_Recordset1['lastname']; ?>
<form name="cowrecord" method="POST" id="cowrecord">
  
  <p><a href="cowrecord.php" data-role="button" data-icon="arrow-l" data-iconpos="top">Close</a> </p>
  <div data-role="fieldcontain">
    <p>
      <label for="cowname"></label>
    </p>
    <table width="400" border="0">
      <tbody>
        <tr>
          <td class="ui-bar-b"><p>Cow Name</p></td>
          <td class="ui-bar-e"><?php echo $row_cowrecord['cowname']; ?></td>
        </tr>
        <tr>
          <td class="ui-bar-b">Date of Birth</td>
          <td class="ui-bar-e"><?php echo $row_cowrecord['dob']; ?></td>
        </tr>
        <tr>
          <td class="ui-bar-b">Sire (Bhuru)</td>
          <td class="ui-bar-e"><?php echo $row_cowrecord['sire']; ?></td>
        </tr>
        <tr>
          <td class="ui-bar-b">Dam (Mai)</td>
          <td class="ui-bar-e"><?php echo $row_cowrecord['dam']; ?></td>
        </tr>
        <tr>
          <td class="ui-bar-b">Weight at 1st service</td>
          <td class="ui-bar-e"><?php echo $row_cowrecord['firstserviceweight']; ?></td>
        </tr>
        <tr>
          <td class="ui-bar-b">Age at 1st Service</td>
          <td class="ui-bar-e"><?php echo $row_cowrecord['firstserviceage']; ?></td>
        </tr>
        <tr>
          <td class="ui-bar-b">Age at 1st Calving</td>
          <td class="ui-bar-e"><?php echo $row_cowrecord['firstcalvingage']; ?></td>
        </tr>
        <tr>
          <td class="ui-bar-b">Age at Conception</td>
          <td class="ui-bar-e"><?php echo $row_cowrecord['conceptionage']; ?></td>
        </tr>
      </tbody>
    </table>
    <p>&nbsp; <a href="<?php printf("%s?pageNum_cowrecord=%d%s", $currentPage, max(0, $pageNum_cowrecord - 1), $queryString_cowrecord); ?>">Previous</a> <a href="<?php printf("%s?pageNum_cowrecord=%d%s", $currentPage, min($totalPages_cowrecord, $pageNum_cowrecord + 1), $queryString_cowrecord); ?>">Next</a></p>
    <p>&nbsp; </p>
</div>
  
</div>
 
 
 </form>
  
  
  <div data-role="footer">
    <h4><img src="assets/Kalloni.png" width="205"></h4>
  </div>
</center>
</div>
</body>
</html>
<?php
mysql_free_result($cowrecord);

mysql_free_result($cowrecord);

mysql_free_result($Recordset1);
?>
