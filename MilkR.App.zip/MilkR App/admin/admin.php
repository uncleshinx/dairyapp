<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>milkR</title>
<link href="jquery-mobile/jquery.mobile-1.3.0.min.css" rel="stylesheet" type="text/css">
<script src="jquery-mobile/jquery-1.11.1.min.js" type="text/javascript"></script>
<script src="jquery-mobile/jquery.mobile-1.3.0.min.js" type="text/javascript"></script>
</head>

<body>
<div data-role="page" id="page">
<center>
  <div data-role="header">
    <h1><img src="assets/logo.png" height="165">&nbsp;</h1>
  </div>
 
 
  <div class="ui-bar-a" data-role="content">
  
   <table width="321" border="0">
  <tbody>
    <tr>
      <td width="105"><div data-role="controlgroup"><a href="index.php" data-role="button">Go Back</a><a href="#" data-role="button">Register</a></div>&nbsp;</td>
      
      <td width="192"> <div data-role="fieldcontain">
      <label for="textinput"></label>
      <strong>
      <input type="text" name="textinput" id="textinput" value="" placeholder="First Name" />
      </strong></div>
    <div data-role="fieldcontain">
      <strong>
      <label for="textinput2"></label>
      <input type="text" name="textinput2" id="textinput2" value="" placeholder="Surname" />
      </strong></div>
    <div data-role="fieldcontain">
      <strong>
      <label for="selectmenu" class="select">I am</label>
      <select name="selectmenu" id="selectmenu">
        <option value="option1">Smallholder Farmer</option>
        <option value="option2">Commercial Farmer</option>
        <option value="option3">Milk Collection Center</option>
        <option value="option2">Regulatory Board</option>
        <option value="option3">Partner</option>
        <option value="option2">Extension Services</option> 
      </select>
      </strong></div>
    <div data-role="fieldcontain">
      <strong>
      <label for="textinput3"></label>
      <input type="text" name="textinput3" id="textinput3" value="" placeholder="Name of Farm/ Organisation" />
      </strong></div>
    <div data-role="fieldcontain">
      <strong>
      <label for="number"></label>
      <input type="number" name="number" id="number" value="" placeholder=" Phone Number"/>
      </strong></div>
    <div data-role="fieldcontain">
      <strong>
      <label for="textinput4"></label>
      <input type="text" name="textinput4" id="textinput4" value="" placeholder="national ID" />
      </strong></div>
    <div data-role="fieldcontain">
      <strong>
      <label for="passwordinput"></label>
      <input type="password" name="passwordinput" id="passwordinput" value="" placeholder="password" />
      </strong>    </div>&nbsp;</td>
    </tr>
  </tbody>
</table>
     
  </div>
  <div data-role="footer">
    <h4><img src="assets/Kalloni.png" width="205"></h4>
  </div>
  </center>
</div>
</body>
</html>