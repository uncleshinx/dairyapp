<?php require_once('Connections/register.php'); ?>
<?php
if (!function_exists("GetSQLValueString")) {
function GetSQLValueString($theValue, $theType, $theDefinedValue = "", $theNotDefinedValue = "") 
{
  if (PHP_VERSION < 6) {
    $theValue = get_magic_quotes_gpc() ? stripslashes($theValue) : $theValue;
  }

  $theValue = function_exists("mysql_real_escape_string") ? mysql_real_escape_string($theValue) : mysql_escape_string($theValue);

  switch ($theType) {
    case "text":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;    
    case "long":
    case "int":
      $theValue = ($theValue != "") ? intval($theValue) : "NULL";
      break;
    case "double":
      $theValue = ($theValue != "") ? doubleval($theValue) : "NULL";
      break;
    case "date":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;
    case "defined":
      $theValue = ($theValue != "") ? $theDefinedValue : $theNotDefinedValue;
      break;
  }
  return $theValue;
}
}

// *** Redirect if username exists
$MM_flag="MM_insert";
if (isset($_POST[$MM_flag])) {
  $MM_dupKeyRedirect="login.php";
  $loginUsername = $_POST['phone'];
  $LoginRS__query = sprintf("SELECT mobile_number FROM login WHERE mobile_number=%s", GetSQLValueString($loginUsername, "int"));
  mysql_select_db($database_register, $register);
  $LoginRS=mysql_query($LoginRS__query, $register) or die(mysql_error());
  $loginFoundUser = mysql_num_rows($LoginRS);

  //if there is a row in the database, the username was found - can not add the requested username
  if($loginFoundUser){
    $MM_qsChar = "?";
    //append the username to the redirect page
    if (substr_count($MM_dupKeyRedirect,"?") >=1) $MM_qsChar = "&";
    $MM_dupKeyRedirect = $MM_dupKeyRedirect . $MM_qsChar ."requsername=".$loginUsername;
    header ("Location: $MM_dupKeyRedirect");
    exit;
  }
}

$editFormAction = $_SERVER['PHP_SELF'];
if (isset($_SERVER['QUERY_STRING'])) {
  $editFormAction .= "?" . htmlentities($_SERVER['QUERY_STRING']);
}

if ((isset($_POST["MM_insert"])) && ($_POST["MM_insert"] == "regform")) {
  $insertSQL = sprintf("INSERT INTO login (firstname, lastname, name, `role`, mobile_number, nationalID, password) VALUES (%s, %s, %s, %s, %s, %s, %s)",
                       GetSQLValueString($_POST['firstname'], "text"),
                       GetSQLValueString($_POST['surname'], "text"),
                       GetSQLValueString($_POST['name'], "text"),
                       GetSQLValueString($_POST['role'], "int"),
                       GetSQLValueString($_POST['phone'], "int"),
                       GetSQLValueString($_POST['ID'], "text"),
                       GetSQLValueString($_POST['password'], "text"));

  mysql_select_db($database_register, $register);
  $Result1 = mysql_query($insertSQL, $register) or die(mysql_error());

  $insertGoTo = "login.php";
  if (isset($_SERVER['QUERY_STRING'])) {
    $insertGoTo .= (strpos($insertGoTo, '?')) ? "&" : "?";
    $insertGoTo .= $_SERVER['QUERY_STRING'];
  }
  header(sprintf("Location: %s", $insertGoTo));
}
?>
<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Registration</title>
<link href="jquery-mobile/jquery.mobile-1.3.0.min.css" rel="stylesheet" type="text/css">
<script src="jquery-mobile/jquery-1.11.1.min.js" type="text/javascript"></script>
<script src="jquery-mobile/jquery.mobile-1.3.0.min.js" type="text/javascript"></script>
<script type="text/javascript" charset="utf-8" src="PushPluginProxy.js"></script>
<script type="text/javascript" charset="utf-8" src="cordova.js"></script>
</head>

<body>
<div data-role="page" id="page">
  <center>
  <div data-role="header">
    <h1><img src="assets/logo.png" height="165">&nbsp;</h1>
  </div>
  <div class="ui-bar-a" data-role="content">
  <form action="<?php echo $editFormAction; ?>" method="POST" id="register" name="regform">
    <a href="index.php" data-role="button" data-icon="arrow-l" data-iconpos="top">Return to Menu</a>
    <div data-role="fieldcontain">
      <label for="firstname"></label>
      <strong>
        <input name="firstname" type="text" required id="firstname" placeholder="First Name" value="" />
      </strong></div>
    <div data-role="fieldcontain"> <strong>
      <label for="surname"></label>
      <input name="surname" type="text" required id="surname" placeholder="Surname" value="" />
    </strong></div>
    <div data-role="fieldcontain"> <strong>
      <label for="role" class="select">I am</label>
      <select name="role" required id="role">
        <option value="option1">a Smallholder Farmer</option>
        <option value="option2">a Commercial Farmer</option>
        <option value="option3">a Milk Collection Center</option>
        <option value="option2">a Regulatory Board</option>
        <option value="option3">a Partner</option>
        <option value="option2">Extension Services</option>
      </select>
    </strong></div>
    <div data-role="fieldcontain"> <strong>
      <label for="name"></label>
      <input name="name" type="text" required id="name" placeholder="Name of Farm/ Organisation" value="" />
    </strong></div>
    <div data-role="fieldcontain"> <strong>
      <label for="phone"></label>
      <input name="phone" type="number" required id="phone" placeholder=" Phone Number" autocomplete="on" value=""/>
    </strong></div>
    <div data-role="fieldcontain"> <strong>
      <label for="ID"></label>
      <input name="ID" type="text" id="ID" placeholder="national ID" value="" />
    </strong></div>
    <div data-role="fieldcontain"> <strong>
      <label for="password"></label>
      <input name="password" type="password" required id="password" placeholder="password" value="" />
    </strong></div>
    <div data-role="fieldcontain"> <strong>
      <button>Submit information</button>
    </strong>
    <input type="hidden" name="MM_insert" value="regform">
    </div>
  </form>
</div>
  

<div data-role="footer">
<h4><img src="assets/Kalloni.png" width="205"></h4>
</div>
</center>
</div>
</body>
</html>
