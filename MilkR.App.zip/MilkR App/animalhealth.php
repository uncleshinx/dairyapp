<?php require_once('Connections/register.php'); ?>
<?php
if (!function_exists("GetSQLValueString")) {
function GetSQLValueString($theValue, $theType, $theDefinedValue = "", $theNotDefinedValue = "") 
{
  if (PHP_VERSION < 6) {
    $theValue = get_magic_quotes_gpc() ? stripslashes($theValue) : $theValue;
  }

  $theValue = function_exists("mysql_real_escape_string") ? mysql_real_escape_string($theValue) : mysql_escape_string($theValue);

  switch ($theType) {
    case "text":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;    
    case "long":
    case "int":
      $theValue = ($theValue != "") ? intval($theValue) : "NULL";
      break;
    case "double":
      $theValue = ($theValue != "") ? doubleval($theValue) : "NULL";
      break;
    case "date":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;
    case "defined":
      $theValue = ($theValue != "") ? $theDefinedValue : $theNotDefinedValue;
      break;
  }
  return $theValue;
}
}

mysql_select_db($database_register, $register);
$query_animal = "SELECT * FROM cowrecord";
$animal = mysql_query($query_animal, $register) or die(mysql_error());
$row_animal = mysql_fetch_assoc($animal);
$totalRows_animal = mysql_num_rows($animal);
?>
<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Log In</title>
<link href="jquery-mobile/jquery.mobile-1.3.0.min.css" rel="stylesheet" type="text/css">
<link href="jQueryAssets/jquery.ui.core.min.css" rel="stylesheet" type="text/css">
<link href="jQueryAssets/jquery.ui.theme.min.css" rel="stylesheet" type="text/css">
<link href="jQueryAssets/jquery.ui.datepicker.min.css" rel="stylesheet" type="text/css">
<script src="jquery-mobile/jquery-1.11.1.min.js" type="text/javascript"></script>
<script src="jquery-mobile/jquery.mobile-1.3.0.min.js" type="text/javascript"></script>
<script src="jQueryAssets/jquery.ui-1.10.4.datepicker.min.js" type="text/javascript"></script>
<script type="text/javascript" charset="utf-8" src="PushPluginProxy.js"></script>
<script type="text/javascript" charset="utf-8" src="cordova.js"></script>
</head>

<body>
<div data-role="page" id="page">

<center>
<div data-role="header">
    <h1><img src="assets/logo.png" height="165">&nbsp;</h1>
  </div>
  <div class="ui-bar-a" data-role="content">
  <a href="animalrecords.php" data-role="button" data-icon="arrow-l" data-iconpos="top">Close</a>
  <div data-role="fieldcontain">
    <label for="selectmenu" class="select">Name of Cow</label>
    <select name="selectmenu" id="selectmenu">
      <?php
do {  
?>
      <option value="<?php echo $row_animal['cowname']?>"<?php if (!(strcmp($row_animal['cowname'], $row_animal['cowname']))) {echo "selected=\"selected\"";} ?>><?php echo $row_animal['cowname']?></option>
      <?php
} while ($row_animal = mysql_fetch_assoc($animal));
  $rows = mysql_num_rows($animal);
  if($rows > 0) {
      mysql_data_seek($animal, 0);
	  $row_animal = mysql_fetch_assoc($animal);
  }
?>
      
    </select>
    <a href="#" data-role="button" data-icon="search" data-iconpos="top">Search for Cow</a>
    -----------------------------------------------------------------------------------------------------------------------
    <center>
Name of Cow:
    </center> 
    <center>
Date of Birth:
    </center>
    <center>
Dam:
    </center>
    <center>
Sire:
    </center>
  
    <p>&nbsp;</p>
    <p>
      <input type="text" id="Datepicker1" placeholder="Date of illness">
    </p>
    <p><div data-role="fieldcontain">
      <p>
        <label for="selectmenu" class="select">Symptoms</label>
        <select name="selectmenu" id="selectmenu">
          
        </select>
      </p>
      <p>
      <div data-role="fieldcontain">
        <p>
          <input type="text" name="textinput" id="textinput" value="" placeholder="Other Symptoms" />
        </p>
        <p>&nbsp;        
        
        <div data-role="fieldcontain">
          <p>
          <label for="selectmenu2" class="select">Treatment</label>
          <select name="selectmenu2" id="selectmenu2" >
            </select>
          </p>
          <p>&nbsp;          
          <div data-role="fieldcontain">
            <p>
              <input type="text" name="textinput2" id="textinput2" value="" placeholder="Other Treatment"/>
            </p>
            <p>&nbsp;            
            <div data-role="fieldcontain">
              <p>$<input type="number" name="number" id="number" value="" placeholder="Cost of Treatment"/>
              </p>
              <p>&nbsp;              
              <div data-role="fieldcontain">
                <p>
                  <input type="text" name="textinput3" id="textinput3" value="" placeholder="Name of Vet"/>
                </p>
                <p>&nbsp;                
                <div data-role="fieldcontain">
                  <input type="text" name="textinput4" id="textinput4" value="" placeholder="remarks/ Comments"/>
                </div>
                </p>
              </div>
              </p>
            </div>
            </p>
          </div>
          </p>
        </div>
        </p>
      </div>
      &nbsp;
      </p>
     
      </p>
      
    </div>
  
    <div>
      <a href="#" data-role="button" data-icon="plus">Save Health Card</a>
</div>
  
  
  
  </div>
  <div data-role="footer">
    <h4><img src="assets/Kalloni.png" width="205"></h4>
  </div>
</div>
</div>
<script type="text/javascript">
$(function() {
	$( "#Datepicker1" ).datepicker(); 
});
$(function() {
	$( "#Datepicker2" ).datepicker(); 
});
$(function() {
	$( "#Datepicker3" ).datepicker(); 
});
$(function() {
	$( "#Datepicker4" ).datepicker(); 
});
$(function() {
	$( "#Datepicker5" ).datepicker(); 
});
$(function() {
	$( "#Datepicker6" ).datepicker(); 
});
$(function() {
	$( "#Datepicker7" ).datepicker(); 
});
$(function() {
	$( "#Datepicker1" ).datepicker(); 
});
$(function() {
	$( "#Datepicker1" ).datepicker(); 
});
$(function() {
	$( "#Datepicker1" ).datepicker(); 
});
$(function() {
	$( "#Datepicker1" ).datepicker(); 
});
</script>
</body>
</html>
<?php
mysql_free_result($animal);
?>
