<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Commercial Farmer</title>
<link href="jquery-mobile/jquery.mobile-1.3.0.min.css" rel="stylesheet" type="text/css">
<link href="jQueryAssets/jquery.ui.core.min.css" rel="stylesheet" type="text/css">
<link href="jQueryAssets/jquery.ui.theme.min.css" rel="stylesheet" type="text/css">
<link href="jQueryAssets/jquery.ui.datepicker.min.css" rel="stylesheet" type="text/css">
<script src="jquery-mobile/jquery-1.11.1.min.js" type="text/javascript"></script>
<script src="jquery-mobile/jquery.mobile-1.3.0.min.js" type="text/javascript"></script>
<script src="jQueryAssets/jquery.ui-1.10.4.datepicker.min.js" type="text/javascript"></script>
<script type="text/javascript" charset="utf-8" src="PushPluginProxy.js"></script>
<script type="text/javascript" charset="utf-8" src="cordova.js"></script>
</head>

<body>
<div data-role="page" id="page">
<center>
  <div data-role="header">
    <h1><img src="assets/logo.png" height="165">&nbsp;</h1>
  </div>
 
 
  
  <div class="ui-bar-a" data-role="content">
  <a href="commercial.php" data-role="button" data-icon="arrow-l" data-iconpos="top">Return to Menu</a>
  <input type="text" id="Datepicker1" placeholder="Date">
  <div data-role="fieldcontain">
    <label for="selectmenu" class="select">Name of Cow</label>
    <select name="selectmenu" id="selectmenu">
     
    </select>
  </div>
 
  <table width="400" border="0">
  <tbody>
    <tr>
      <td>Time of Day</td>
      <td><select name="selectmenu2" id="selectmenu2">
        <option value="morning">Morning</option>
        <option value="midmorning">Mid - Morning</option>
        <option value="afternoon">Afternoon</option>
      </select></td>
    </tr>
    <tr>
      <td>Milk Yield</td>
      <td>&nbsp;
        <div data-role="fieldcontain">
          <div data-role="fieldcontain">
          <input type="number" name="number" id="number" value=""  />
          </div>
        </div></td>
    </tr>
    <tr>
      <td>Mastitis test results</td>
      <td>&nbsp;
        <div data-role="fieldcontain">
          <select name="selectmenu3" id="selectmenu3">
            <option value="no">No</option>
            <option value="yes">Yes</option>
          </select>
        </div></td>
    </tr>
  </tbody>
</table>


  
  <div data-role="fieldcontain">
    <label for="number5">Domestic Milk</label>
    <input type="number" name="number5" id="number5" value="" />
  </div>
   <div data-role="fieldcontain">
    <label for="number5">Total milk to be sold</label>
    <input type="number" name="number5" id="number5" value="" />
  </div>
  <div data-role="fieldcontain">
    <label for="number5">Today's Selling Price</label>
    <input type="number" name="number5" id="number5" value="" />
  </div>
  <div data-role="fieldcontain">
    <label for="number2">Cash Sale</label>
    <input type="number" name="number2" id="number2" value=""  />
  </div>
<a href="#" data-role="button" data-icon="home">Save milkSheet</a>
  
  
  </div>
  <div data-role="footer">
    <h4><img src="assets/Kalloni.png" width="205"></h4>
  </div>
  </center>
</div>
<script type="text/javascript">
$(function() {
	$( "#Datepicker1" ).datepicker(); 
});
</script>
</body>
</html>