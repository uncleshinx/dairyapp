<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Log In</title>
<link href="jquery-mobile/jquery.mobile-1.3.0.min.css" rel="stylesheet" type="text/css">
<script src="jquery-mobile/jquery-1.11.1.min.js" type="text/javascript"></script>
<script src="jquery-mobile/jquery.mobile-1.3.0.min.js" type="text/javascript"></script>
<script type="text/javascript" charset="utf-8" src="PushPluginProxy.js"></script>
<script type="text/javascript" charset="utf-8" src="cordova.js"></script>
</head>

<body>
<div data-role="page" id="page">
<center>
  <div data-role="header">
    <h1><img src="assets/logo.png" height="165">&nbsp;</h1>
  </div>
 
 
  
  <div class="ui-bar-a" data-role="content">
  <a href="index.php" data-role="button" data-icon="arrow-l" data-iconpos="top">Close</a>
  <div data-role="fieldcontain">
    <label for="selectmenu" class="select">Name of Cow</label>
    <select name="selectmenu" id="selectmenu">
     
    </select>
    <a href="#" data-role="button" data-icon="search">Search Milk Records</a>
  </div>
 
 .....................................................................................................................
 
 <table width="400" border="0">
  <tbody>
    <tr>
      <td>Date </td>
      <td>Cow</td>
      <td>Total Yield</td>
      <td>Rejected Milk</td>
    </tr>
  </tbody>
</table>
 
  
  
  </div>
  <div data-role="footer">
    <h4><img src="assets/Kalloni.png" width="205"></h4>
  </div>
  </center>
</div>
</body>
</html>