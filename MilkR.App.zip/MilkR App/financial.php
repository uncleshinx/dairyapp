<?php require_once('Connections/register.php'); ?>
<?php
if (!function_exists("GetSQLValueString")) {
function GetSQLValueString($theValue, $theType, $theDefinedValue = "", $theNotDefinedValue = "") 
{
  if (PHP_VERSION < 6) {
    $theValue = get_magic_quotes_gpc() ? stripslashes($theValue) : $theValue;
  }

  $theValue = function_exists("mysql_real_escape_string") ? mysql_real_escape_string($theValue) : mysql_escape_string($theValue);

  switch ($theType) {
    case "text":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;    
    case "long":
    case "int":
      $theValue = ($theValue != "") ? intval($theValue) : "NULL";
      break;
    case "double":
      $theValue = ($theValue != "") ? doubleval($theValue) : "NULL";
      break;
    case "date":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;
    case "defined":
      $theValue = ($theValue != "") ? $theDefinedValue : $theNotDefinedValue;
      break;
  }
  return $theValue;
}
}

$currentPage = $_SERVER["PHP_SELF"];

$maxRows_milksheet = 1;
$pageNum_milksheet = 0;
if (isset($_GET['pageNum_milksheet'])) {
  $pageNum_milksheet = $_GET['pageNum_milksheet'];
}
$startRow_milksheet = $pageNum_milksheet * $maxRows_milksheet;

mysql_select_db($database_register, $register);
$query_milksheet = "SELECT * FROM sfmilkrecord";
$query_limit_milksheet = sprintf("%s LIMIT %d, %d", $query_milksheet, $startRow_milksheet, $maxRows_milksheet);
$milksheet = mysql_query($query_limit_milksheet, $register) or die(mysql_error());
$row_milksheet = mysql_fetch_assoc($milksheet);

if (isset($_GET['totalRows_milksheet'])) {
  $totalRows_milksheet = $_GET['totalRows_milksheet'];
} else {
  $all_milksheet = mysql_query($query_milksheet);
  $totalRows_milksheet = mysql_num_rows($all_milksheet);
}
$totalPages_milksheet = ceil($totalRows_milksheet/$maxRows_milksheet)-1;

mysql_select_db($database_register, $register);
$query_inputs = "SELECT * FROM inputpurchase";
$inputs = mysql_query($query_inputs, $register) or die(mysql_error());
$row_inputs = mysql_fetch_assoc($inputs);
$totalRows_inputs = mysql_num_rows($inputs);

mysql_select_db($database_register, $register);
$query_cashflow = "SELECT * FROM about";
$cashflow = mysql_query($query_cashflow, $register) or die(mysql_error());
$row_cashflow = mysql_fetch_assoc($cashflow);
$totalRows_cashflow = mysql_num_rows($cashflow);

$queryString_milksheet = "";
if (!empty($_SERVER['QUERY_STRING'])) {
  $params = explode("&", $_SERVER['QUERY_STRING']);
  $newParams = array();
  foreach ($params as $param) {
    if (stristr($param, "pageNum_milksheet") == false && 
        stristr($param, "totalRows_milksheet") == false) {
      array_push($newParams, $param);
    }
  }
  if (count($newParams) != 0) {
    $queryString_milksheet = "&" . htmlentities(implode("&", $newParams));
  }
}
$queryString_milksheet = sprintf("&totalRows_milksheet=%d%s", $totalRows_milksheet, $queryString_milksheet);
?>
<!doctype html>
<html>
<head>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>milkR</title>
<link href="jquery-mobile/jquery.mobile-1.3.0.min.css" rel="stylesheet" type="text/css">
<!-- <link href="css/bootstrap.css" rel="stylesheet" type="text/css"> -->
<link href="css/bootstrap-3.3.4.css" rel="stylesheet" type="text/css">
<script src="jquery-mobile/jquery-1.11.1.min.js" type="text/javascript"></script>
<script type="text/javascript" charset="utf-8" src="PushPluginProxy.js"></script>
<script type="text/javascript" charset="utf-8" src="cordova.js"></script>
<script src="jquery-mobile/jquery.mobile-1.3.0.min.js" type="text/javascript"></script>
<!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
<!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
<!--[if lt IE 9]>
<script src="https://oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js"></script>
<script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
<![endif]-->
<script language='JavaScript' type='text/javascript' src='JScript/CalculatedField.js'></script>
</head>

<body>
<div data-role="page" id="page">
<center>
  <div data-role="header">
    <h1><img src="assets/logo.png" height="108" width="119">&nbsp;</h1>
  </div>
  <div data-role="content">
    <div data-role="fieldcontain">
      <label for="textinput"></label>
    </div>
    <a href="smallholder.php" data-role="button" data-icon="arrow-l" data-iconpos="top">Return to Menu</a>
  <h1>Daily Financial Report</h1>
  <p>&nbsp;  
  <div data-role="fieldcontain">
    <input type="search" name="financialsearch" id="financialsearch" value=""  />
  <input type="button" name="Search" id="Search">
  </div>
  </p>
  <form id="profit" name="profit">
    <table width="400" border="0">
      <tbody>
        <tr>
          <td width="121" class="btn-default">Date</td>
          <td width="82" class="btn-success">Income</td>
          <td width="78" class="btn-danger">Expenses</td>
          
        </tr>
        <tr>
          <td class="btn-default"><?php echo $row_milksheet['date']; ?></td>
          <td class="btn-success">$
            <input name="income" type="number" id="income" value="<?php echo $row_milksheet['totalsales']; ?>" readonly></td>
          <td class="btn-danger">$
            <input name="expenses" type="number" id="expenses" value="<?php echo $row_inputs['depreciation']; ?>" readonly></td>
        </tr>
        <tr>
          <td class="btn-default">&nbsp;</td>
          <td class="btn-success">&nbsp;</td>
          <td class="btn-danger">&nbsp;</td>
          <td class="btn-lg">&nbsp;</td>
        </tr>
      </tbody>
    </table>
    <p>&nbsp;</p>
    <p>&nbsp;Total Records<?php echo $totalRows_milksheet ?> <a href="<?php printf("%s?pageNum_milksheet=%d%s", $currentPage, max(0, $pageNum_milksheet - 1), $queryString_milksheet); ?>"> Previous</a> <a href="<?php printf("%s?pageNum_milksheet=%d%s", $currentPage, min($totalPages_milksheet, $pageNum_milksheet + 1), $queryString_milksheet); ?>">Next</a></p>
    <div data-role="fieldcontain">
      <label for="profit">
        <input type="hidden" name="expenses" id="expenses">
        <input type="hidden" name="income" id="income">
      </label>
       
    </div>
    </div>
   
  </form>
  
  </div>
  <div data-role="footer">
    <h4><img src="assets/Kalloni.png" width="205"></h4>
  </div>
  </center>
</div>
<!-- <script src="js/bootstrap.js" type="text/javascript"></script> -->
<script src="js/bootstrap-3.3.4.js" type="text/javascript"></script>
</body>
</html>
<?php
mysql_free_result($milksheet);

mysql_free_result($inputs);

mysql_free_result($cashflow);
?>
