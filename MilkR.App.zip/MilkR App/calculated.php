<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Untitled Document</title>
<link href="jquery-mobile/jquery.mobile-1.3.0.min.css" rel="stylesheet" type="text/css">
<script src="jquery-mobile/jquery-1.11.1.min.js" type="text/javascript"></script>
<script src="jquery-mobile/jquery.mobile-1.3.0.min.js" type="text/javascript"></script>
<script language='JavaScript' type='text/javascript' src='JScript/CalculatedField.js'></script>
<script type="text/javascript" charset="utf-8" src="PushPluginProxy.js"></script>
<script type="text/javascript" charset="utf-8" src="cordova.js"></script>
</head>

<body>
<div data-role="page" id="page">
  <div data-role="header">
    <h1>Header</h1>
  </div>
  <div data-role="content">
    <form id="form1" name="form1" method="post">
      <div data-role="fieldcontain">
        <label for="number">Number:</label>
        <input type="number" name="number" id="number1" value=""  />
        <div data-role="fieldcontain">
          <label for="number2">Number:</label>
          <input type="number" name="number2" id="number2" value=""  />
          <div data-role="fieldcontain">
            <label for="number3">Total:</label>
            <input type="number" name="number3" id="number3" value=""  />
            <div data-role="fieldcontain">
              <input type="hidden" name="hiddenField" id="hiddenField">
            </div>
          </div>
        </div>
      </div>
    </form>
    <script>
function calcField_form1(){
CalcField.addEquation('form1', 'number3=number*number2');
  CalcField.addEquation('form1', 'number3=number*number2');
}
calcField_form1();
    </script>
  </div>
  <div data-role="footer">
    <h4>Footer</h4>
  </div>
</div>
</body>
</html>