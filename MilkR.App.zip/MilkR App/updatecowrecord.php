<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Log In</title>
<link href="jquery-mobile/jquery.mobile-1.3.0.min.css" rel="stylesheet" type="text/css">
<link href="jQueryAssets/jquery.ui.core.min.css" rel="stylesheet" type="text/css">
<link href="jQueryAssets/jquery.ui.theme.min.css" rel="stylesheet" type="text/css">
<link href="jQueryAssets/jquery.ui.datepicker.min.css" rel="stylesheet" type="text/css">
<script src="jquery-mobile/jquery-1.11.1.min.js" type="text/javascript"></script>
<script src="jquery-mobile/jquery.mobile-1.3.0.min.js" type="text/javascript"></script>
<script src="jQueryAssets/jquery.ui-1.10.4.datepicker.min.js" type="text/javascript"></script>
<script type="text/javascript" charset="utf-8" src="PushPluginProxy.js"></script>
<script type="text/javascript" charset="utf-8" src="cordova.js"></script>
</head>

<body>
<div data-role="page" id="page">
<center>
  <div data-role="header">
    <h1><img src="assets/logo.png" height="165">&nbsp;</h1>
  </div>
 
 
  
  <div class="ui-bar-a" data-role="content">
  <a href="cowrecord.php" data-role="button" data-icon="arrow-l" data-iconpos="top">Close</a>
  <div data-role="fieldcontain">
    <label for="selectmenu" class="select">Name of Cow</label>
    <select name="selectmenu" id="selectmenu">
      
    </select>
    <a href="#" data-role="button" data-icon="search" data-iconpos="top">Search for Cow</a>
    -----------------------------------------------------------------------------------------------------------------------
    <center>
Name of Cow:
    </center> 
    <center>
Date of Birth:
    </center>
    <center>
Dam:
    </center>
    <center>
Sire:
    </center>
    <input type="text" id="Datepicker1" placeholder="Date of Heat">
    <input type="text" id="Datepicker2" placeholder="Date of AI">
    <input type="text" id="Datepicker3" placeholder="Date of Service">
    <input type="text" id="Datepicker4" placeholder="Date of Pregnancy Diagnosis">
    <input type="text" id="Datepicker5" placeholder="Date of Calving">
    <input type="text" id="Datepicker6" placeholder="Date due to calf">
    <input type="text" id="Datepicker7" placeholder="Date to Dry">
    <div data-role="fieldcontain">
      <label for="selectmenu2" class="select">Sex of Calf</label>
      <select name="selectmenu2" id="selectmenu2">
        <option value="option1">Male</option>
        <option value="option2">Female</option>
      </select>
    </div>
    <div data-role="fieldcontain">
      <label for="number"></label>
      <input type="number" name="number" id="number" value="" placeholder="Calving Interval" />
    </div>
    <a href="#" data-role="button" data-icon="plus">Update Cow Record</a>
  </div>
  
  
  
  </div>
  <div data-role="footer">
    <h4><img src="assets/Kalloni.png" width="205"></h4>
  </div>
  </center>
</div>
<script type="text/javascript">
$(function() {
	$( "#Datepicker1" ).datepicker(); 
});
$(function() {
	$( "#Datepicker2" ).datepicker(); 
});
$(function() {
	$( "#Datepicker3" ).datepicker(); 
});
$(function() {
	$( "#Datepicker4" ).datepicker(); 
});
$(function() {
	$( "#Datepicker5" ).datepicker(); 
});
$(function() {
	$( "#Datepicker6" ).datepicker(); 
});
$(function() {
	$( "#Datepicker7" ).datepicker(); 
});
</script>
</body>
</html>