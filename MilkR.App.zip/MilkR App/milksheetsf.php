<?php require_once('Connections/register.php'); ?>
<?php
if (!function_exists("GetSQLValueString")) {
function GetSQLValueString($theValue, $theType, $theDefinedValue = "", $theNotDefinedValue = "") 
{
  if (PHP_VERSION < 6) {
    $theValue = get_magic_quotes_gpc() ? stripslashes($theValue) : $theValue;
  }

  $theValue = function_exists("mysql_real_escape_string") ? mysql_real_escape_string($theValue) : mysql_escape_string($theValue);

  switch ($theType) {
    case "text":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;    
    case "long":
    case "int":
      $theValue = ($theValue != "") ? intval($theValue) : "NULL";
      break;
    case "double":
      $theValue = ($theValue != "") ? doubleval($theValue) : "NULL";
      break;
    case "date":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;
    case "defined":
      $theValue = ($theValue != "") ? $theDefinedValue : $theNotDefinedValue;
      break;
  }
  return $theValue;
}
}

$editFormAction = $_SERVER['PHP_SELF'];
if (isset($_SERVER['QUERY_STRING'])) {
  $editFormAction .= "?" . htmlentities($_SERVER['QUERY_STRING']);
}

if ((isset($_POST["MM_insert"])) && ($_POST["MM_insert"] == "form1")) {
  $insertSQL = sprintf("INSERT INTO sfmilkrecord (`date`, cowid, yieldA, yieldB, yieldC, totalyield, rejected, unitcost, totalsales) VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s)",
                       GetSQLValueString($_POST['date'], "date"),
                       GetSQLValueString($_POST['selectmenu'], "int"),
                       GetSQLValueString($_POST['yieldA'], "double"),
                       GetSQLValueString($_POST['yieldB'], "double"),
                       GetSQLValueString($_POST['yieldC'], "double"),
                       GetSQLValueString($_POST['rejected'], "double"),
                       GetSQLValueString($_POST['totalyield'], "double"),
                       GetSQLValueString($_POST['unitcost'], "double"),
                       GetSQLValueString($_POST['totalsales'], "double"));

  mysql_select_db($database_register, $register);
  $Result1 = mysql_query($insertSQL, $register) or die(mysql_error());

  $insertGoTo = "financial.php";
  if (isset($_SERVER['QUERY_STRING'])) {
    $insertGoTo .= (strpos($insertGoTo, '?')) ? "&" : "?";
    $insertGoTo .= $_SERVER['QUERY_STRING'];
  }
  header(sprintf("Location: %s", $insertGoTo));
}

mysql_select_db($database_register, $register);
$query_cowrecord = "SELECT * FROM cowrecord";
$cowrecord = mysql_query($query_cowrecord, $register) or die(mysql_error());
$row_cowrecord = mysql_fetch_assoc($cowrecord);
$totalRows_cowrecord = mysql_num_rows($cowrecord);

mysql_select_db($database_register, $register);
$query_milksheet = "SELECT * FROM sfmilkrecord";
$milksheet = mysql_query($query_milksheet, $register) or die(mysql_error());
$row_milksheet = mysql_fetch_assoc($milksheet);
$totalRows_milksheet = mysql_num_rows($milksheet);
?>
<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title> Milksheet</title>
<link href="jquery-mobile/jquery.mobile-1.3.0.min.css" rel="stylesheet" type="text/css">
<link href="jQueryAssets/jquery.ui.core.min.css" rel="stylesheet" type="text/css">
<link href="jQueryAssets/jquery.ui.theme.min.css" rel="stylesheet" type="text/css">
<link href="jQueryAssets/jquery.ui.datepicker.min.css" rel="stylesheet" type="text/css">
<script src="jquery-mobile/jquery-1.11.1.min.js" type="text/javascript"></script>
<script src="jquery-mobile/jquery.mobile-1.3.0.min.js" type="text/javascript"></script>
<script src="jQueryAssets/jquery.ui-1.10.4.datepicker.min.js" type="text/javascript"></script>
<script language='JavaScript' type='text/javascript' src='JScript/CalculatedField.js'></script>

</head>

<body>
<div data-role="page" id="page">
<center>
<div data-role="header">
    <h1><img src="assets/logo.png" width="117" height="106">&nbsp;</h1>
  </div>
 
 
  
<div class="ui-bar-a" data-role="content">
  <a href="smallholder.php" data-role="button" data-icon="arrow-l" data-iconpos="top">Return to Menu</a>
  <form action="<?php echo $editFormAction; ?>" id="form1" name="form1" method="POST">
  <label for="date">Date</label>
  <input name="date" type="date" id="date" min="2016-03-01">
<div data-role="fieldcontain">
    <p>
      <label for="selectmenu" class="select">Name of Cow</label>
      <select name="selectmenu" id="selectmenu">
        <?php
do {  
?>
        <option value="<?php echo $row_cowrecord['cowname']?>"<?php if (!(strcmp($row_cowrecord['cowname'], $row_cowrecord['cowname']))) {echo "selected=\"selected\"";} ?>><?php echo $row_cowrecord['cowname']?></option>
        <?php
} while ($row_cowrecord = mysql_fetch_assoc($cowrecord));
  $rows = mysql_num_rows($cowrecord);
  if($rows > 0) {
      mysql_data_seek($cowrecord, 0);
	  $row_cowrecord = mysql_fetch_assoc($cowrecord);
  }
?>
      </select>
    </p>
    
      <table width="400" border="1">
        <tbody>
          <tr>
            <td class="ui-bar-b"><p>Morning Yield</p>
              <p>&nbsp;</p>
              <p>Mastitis </p></td>
            <td class="ui-bar-e">&nbsp;
              <div data-role="fieldcontain">
                <input type="number" name="yieldA" id="yieldA" value=""  />
                kg
                <input type="hidden" name="yield1" id="yield1">
                <input type="hidden" name="a_yield" id="a_yield">
              </div>
              <div data-role="fieldcontain">
                <p>&nbsp;</p>
                <p>&nbsp;                
                  
                <div data-role="fieldcontain">
                  <select name="masA" id="masA">
                    <option value="0">No</option>
                    <option value="1">Yes</option>
                  </select>
                </div>
                <p></p>
              </div></td>
          </tr>
          <tr>
            <td class="ui-bar-b"><p>Mid - Morning Yield</p>
              <p>&nbsp;</p>
              <p>Mastitis</p></td>
            <td class="ui-bar-e">&nbsp;
              <div data-role="fieldcontain">
                <input type="number" name="yieldB" id="yieldB" value=""  />
                kg
                <input type="hidden" name="yield2" id="yield2">
                <input type="hidden" name="b_yield" id="b_yield">
              </div>
              <div data-role="fieldcontain">
                <p>&nbsp;</p>
                <p>&nbsp;                
                  
                <div data-role="fieldcontain">
                  <select name="selectmenu2" id="selectmenu2">
                    <option value="0">No</option>
                    <option value="1">Yes</option>
                  </select>
                </div>
                <p></p>
              </div></td>
          </tr>
          <tr>
            <td class="ui-bar-b"><p>Afternoon Yield</p>
              <p>&nbsp;</p>
              <p>Mastitis</p></td>
            <td class="ui-bar-e"><p>&nbsp;            
            <div data-role="fieldcontain">
              <input type="number" name="yieldC" id="yieldC" value=""  />
              kg
              <input type="hidden" name="yield3" id="yield3">
              <input type="hidden" name="c_yield" id="c_yield">
            </div>
              <p></p>
              <p>&nbsp;
              <div data-role="fieldcontain">
                <select name="selectmenu3" id="selectmenu3">
                  <option value="0">No</option>
                  <option value="1">Yes</option>
                </select>
              </div>
              <p></p></td>
          </tr>
          <tr>
            <td class="ui-bar-b">Domestic Milk</td>
            <td class="ui-bar-e">&nbsp;
              <div data-role="fieldcontain">
                <input type="number" name="totalyield" id="totalyield" value=""  />
                kg
                <input type="hidden" name="totalyield1" id="totalyield1">
                <input type="hidden" name="mastitis" id="mastitis">
              </div></td>
          </tr>
          <tr>
            <td class="ui-bar-b">Total Yield</td>
            <td class="ui-bar-e">&nbsp;
              <div data-role="fieldcontain">
                <input type="number" name="rejected" id="rejected" value=""  />
                kg
                <input type="hidden" name="rejected1" id="rejected1">
              </div></td>
          </tr>
          <tr>
            <td class="ui-bar-b">Today's Selling Price</td>
            <td class="ui-bar-e">&nbsp;
             <div data-role="fieldcontain">
               <label for="unitcost">$</label>
               <input name="unitcost" type="number" id="unitcost" form="form1" min="0" step="0.01">
             </div></td>
          </tr>
        </tbody>
      </table>
      <table width="400" border="0">
        <tbody>
          <tr> </tr>
        </tbody>
      </table>
      <div data-role="fieldcontain"> My sales today  
        $
        <input type="number" name="totalsales" id="totalsales" value=""  />
        <input type="hidden" name="sales" id="sales">
      </div>
       <div data-role="fieldcontain"> <strong>
      <button>Submit MilkSheet</button>
    </strong>
    </div>
       <input type="hidden" name="MM_insert" value="form1">
  </form>
    <script>
function calcField_form1(){
CalcField.addEquation('form1', 'totalyield=masA*yieldA+selectmenu2*yieldB+selectmenu3*yieldC');
  CalcField.addEquation('form1', 'rejected=yieldA+yieldB+yieldC-totalyield');
   CalcField.addEquation('form1', 'totalsales=rejected*unitcost');
}
calcField_form1();
    </script>
  </div>
  <div data-role="footer">
    <h4><img src="assets/Kalloni.png" width="205"></h4>
  </div>
  </center>
</div>
<script type="text/javascript">
$(function() {
	$( "#Datepicker1" ).datepicker(); 
});
</script>
</body>
</html>
<?php
mysql_free_result($cowrecord);

mysql_free_result($milksheet);
?>
