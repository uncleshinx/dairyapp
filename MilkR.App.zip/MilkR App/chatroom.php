<!doctype html>
<html>
<head>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>milkR</title>
<link href="jquery-mobile/jquery.mobile-1.3.0.min.css" rel="stylesheet" type="text/css">
<!-- <link href="css/bootstrap.css" rel="stylesheet" type="text/css"> -->
<link href="css/bootstrap-3.3.4.css" rel="stylesheet" type="text/css">
<script src="jquery-mobile/jquery-1.11.1.min.js" type="text/javascript"></script>
<script type="text/javascript" charset="utf-8" src="PushPluginProxy.js"></script>
<script type="text/javascript" charset="utf-8" src="cordova.js"></script>
<script src="jquery-mobile/jquery.mobile-1.3.0.min.js" type="text/javascript"></script>
<!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
<!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
<!--[if lt IE 9]>
<script src="https://oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js"></script>
<script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
<![endif]-->
<script type="text/javascript" src="http://download.skype.com/share/skypebuttons/js/skypeCheck.js"></script>
</head>

<body>
<div data-role="page" id="page">
<center>
  <div data-role="header">
    <h1><img src="assets/logo.png" height="108" width="119">&nbsp;</h1>
  </div>
 <a href="smallholder.php" data-role="button" data-icon="arrow-l" data-iconpos="top">Return to Menu</a><a href="skype:myfarmhouse?call"><img src="http://download.skype.com/share/skypebuttons/buttons/call_blue_white_124x52.png" style="border: none;" width="124" height="52" alt="Call me!" /></a>
 
 
 
    <table width="400" border="0">
  <tbody>
    <tr>
      <td><div id="carousel1" class="carousel slide" data-ride="carousel">
        <ol class="carousel-indicators">
          <li data-target="#carousel1" data-slide-to="0" class="active"></li>
          <li data-target="#carousel1" data-slide-to="1"></li>
          <li data-target="#carousel1" data-slide-to="2"></li>
        </ol>
        <div class="carousel-inner" role="listbox">
          <div class="item active"><img src="assets/produce.jpg" alt="First slide image" width="390" class="center-block">
            <div class="carousel-caption">
              <h3>buy Farm fresh produce</h3>
              <p>Kubva ku Kalloni Farmhouse</p>
            </div>
          </div>
          <div class="item"><img src="assets/meat_rgb2.jpg" alt="Second slide image" class="center-block">
            <div class="carousel-caption">
              <h3>Uri kutengesa nyama yako here?</h3>
              <p>svika ku Kalloni Farmhouse nhasi chaiye</p>
            </div>
          </div>
          <div class="item"><img src="assets/milk-product.jpg" alt="Third slide image" class="center-block">
            <div class="carousel-caption">
              <h3></h3>
              <p></p>
            </div>
          </div>
        </div>
        <a class="left carousel-control" href="#carousel1" role="button" data-slide="prev"><span class="glyphicon glyphicon-chevron-left" aria-hidden="true"></span><span class="sr-only">Previous</span></a><a class="right carousel-control" href="#carousel1" role="button" data-slide="next"><span class="glyphicon glyphicon-chevron-right" aria-hidden="true"></span><span class="sr-only">Next</span></a></div></td>
    </tr>
    <tr>
      <td>&nbsp;
      </td>
    </tr>
  </tbody>
</table>


  <div data-role="content">
    
   
  
    
    
</div>
  <div data-role="footer">
    <h4><img src="assets/Kalloni.png" width="205"></h4>
  </div>
  </center>
</div>
<!-- <script src="js/bootstrap.js" type="text/javascript"></script> -->
<script src="js/bootstrap-3.3.4.js" type="text/javascript"></script>
</body>
</html>